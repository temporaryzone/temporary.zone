---
obsah:
    text: "# temporary.zone\r\n\r\nDočasná zóna je neziskové open-source design studio. Jsme skupina angažovaných designéru, umělců a programátorů, kteří využívají nové a alternativní způsoby rozložení práce. Inspirují nás principy fungování open-source komunity, které aplikujeme na design a umění.\r\n\r\nPomáháme neziskovým organizacím a projektům, nebo projekty sami iniciujeme. \r\nNaše výstupy jsou věřejně přístupné a mají otevřenou licenci."
    help: help
    themes: ffff
title: temporary.zone
---

# temporary.zone

Dočasná zóna je neziskové open-source design studio. Jsme skupina angažovaných designéru, umělců a programátorů, kteří využívají nové a alternativní způsoby rozložení práce. Inspirují nás principy fungování open-source komunity, které aplikujeme na design a umění.

Pomáháme neziskovým organizacím a projektům, nebo projekty sami iniciujeme. 
Naše výstupy jsou věřejně přístupné a mají otevřenou licenci.

Témata, která nas zajímají:

  * svobodný internet
  * bezpečnost na internetu
  * osobní soukromí a práva
  * decentralizace a lokálnost
  * komunita a kolaborace
  * sociální problémy
  * architektura a urbanismus
  * open-source projekty

S čím můžeme pomoci

  * veškerá prezentace a propagace
  * média (tisk, video, web, ux/ui)
  * organizace projektů a akcí


