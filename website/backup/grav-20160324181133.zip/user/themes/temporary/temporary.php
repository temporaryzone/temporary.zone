<?php
namespace Grav\Theme;

use Grav\Common\Theme;

class Temporary extends Theme
{

}